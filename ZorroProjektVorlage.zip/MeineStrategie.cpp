// Meine Strategievorlage
#include <zorro.h>
#include <profile.c>

DLLFUNC void main()  
{
	// F�r sp�ter 
}


DLLFUNC void run()							// Wird bei jedem Bar Ausgef�hrt 
{
	set(PLOTNOW);							// PLOTNOW (Schalter) Flag wird gesetzt um sofort bei test ein Plot mit daten zu zeichnen  

	vars Prices = series(priceClose(0));  	// mit "vars" wird eine Variable mit dem Namen Prices angelegt, und eine bei jedem 
											// run () aufruf wird der Prices Variable der price aus der serie zugewisen.. 
											// in C/C++ mit paramter ,Aktueller Bar is 0
}



